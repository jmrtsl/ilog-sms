-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2021 at 03:55 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rfidattendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(30) NOT NULL,
  `admin_email` varchar(80) NOT NULL,
  `admin_pwd` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_email`, `admin_pwd`) VALUES
(1, 'Admin', 'admin@gmail.com', '$2y$10$89uX3LBy4mlU/DcBveQ1l.32nSianDP/E1MfUh.Z.6B4Z0ql3y7PK');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `device_name` varchar(50) NOT NULL,
  `device_dep` varchar(20) NOT NULL,
  `device_uid` text NOT NULL,
  `device_date` date NOT NULL,
  `device_mode` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `device_name`, `device_dep`, `device_uid`, `device_date`, `device_mode`) VALUES
(1, 'Test', 'First floor', '249c2936ed4737e1', '2021-04-17', 1),
(2, 'INHS', 'Faculty', '6e31a295c97ffe04', '2021-04-18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `card_uid` varchar(250) NOT NULL,
  `number` varchar(250) NOT NULL,
  `sent_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `card_uid`, `number`, `sent_status`) VALUES
(1, '13715982162', '09751395645', 1),
(2, '247267999', '09751395645', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT 'None',
  `serialnumber` double NOT NULL DEFAULT 0,
  `gender` varchar(10) NOT NULL DEFAULT 'None',
  `email` varchar(50) NOT NULL DEFAULT 'None',
  `card_uid` varchar(30) NOT NULL,
  `card_select` tinyint(1) NOT NULL DEFAULT 0,
  `user_date` date NOT NULL,
  `device_uid` varchar(20) NOT NULL DEFAULT '0',
  `device_dep` varchar(20) NOT NULL DEFAULT '0',
  `add_card` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `serialnumber`, `gender`, `email`, `card_uid`, `card_select`, `user_date`, `device_uid`, `device_dep`, `add_card`) VALUES
(2, 'kiel', 123, 'Male', 'kiel@gmail.com', '247267999', 1, '2021-04-17', '249c2936ed4737e1', 'First floor', 1),
(3, 'jimboy', 12, 'Male', 'imprincejl@gmail.com', '13715982162', 0, '2021-04-21', '249c2936ed4737e1', 'First floor', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_logs`
--

CREATE TABLE `users_logs` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `serialnumber` double NOT NULL,
  `card_uid` varchar(30) NOT NULL,
  `device_uid` varchar(20) NOT NULL,
  `device_dep` varchar(20) NOT NULL,
  `checkindate` date NOT NULL,
  `timein` time NOT NULL,
  `timeout` time NOT NULL,
  `card_out` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_logs`
--

INSERT INTO `users_logs` (`id`, `username`, `serialnumber`, `card_uid`, `device_uid`, `device_dep`, `checkindate`, `timein`, `timeout`, `card_out`) VALUES
(1, 'Test2', 2, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-17', '14:43:55', '14:43:57', 1),
(2, 'Test2', 2, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-17', '14:44:13', '15:03:49', 1),
(3, 'Test 1', 1, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-17', '15:01:57', '15:01:59', 1),
(4, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-17', '15:04:01', '15:05:02', 1),
(5, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-17', '15:05:14', '15:05:29', 1),
(6, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-17', '15:07:53', '15:08:00', 1),
(7, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-18', '07:17:36', '07:19:01', 1),
(8, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-18', '07:17:39', '07:18:34', 1),
(9, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-18', '07:19:03', '07:19:09', 1),
(10, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-18', '07:19:07', '07:19:11', 1),
(11, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-18', '07:20:49', '07:21:44', 1),
(12, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-18', '07:22:03', '07:22:33', 1),
(13, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-18', '07:23:38', '13:26:22', 1),
(14, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-18', '13:27:33', '13:29:07', 1),
(15, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-18', '13:29:15', '13:29:17', 1),
(16, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-18', '13:32:56', '13:33:07', 1),
(17, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-18', '13:33:04', '13:33:12', 1),
(18, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-21', '06:38:00', '07:28:30', 1),
(19, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-21', '06:38:11', '07:28:38', 1),
(20, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-21', '07:33:26', '07:33:29', 1),
(21, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-21', '07:33:44', '07:34:06', 1),
(22, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-21', '07:33:52', '07:34:25', 1),
(23, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-21', '08:00:27', '08:00:28', 1),
(24, 'Jim', 1234, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-21', '08:00:43', '08:04:26', 1),
(25, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-21', '08:04:29', '08:17:12', 1),
(26, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-21', '08:04:32', '08:17:28', 1),
(27, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-21', '08:17:16', '00:00:00', 0),
(28, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-21', '08:17:31', '00:00:00', 0),
(29, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:38:38', '13:41:03', 1),
(30, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:39:02', '13:40:52', 1),
(31, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:40:54', '13:49:40', 1),
(32, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:49:42', '13:49:58', 1),
(33, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:50:04', '13:50:12', 1),
(34, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:50:48', '13:53:32', 1),
(35, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:51:15', '13:51:38', 1),
(36, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:54:35', '13:57:00', 1),
(37, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:57:01', '14:07:55', 1),
(38, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '13:59:56', '14:00:02', 1),
(39, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:08:05', '14:37:58', 1),
(40, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:08:14', '14:08:18', 1),
(41, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:10:22', '14:38:25', 1),
(42, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:38:18', '14:49:34', 1),
(43, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:49:27', '14:52:30', 1),
(44, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:53:25', '14:59:44', 1),
(45, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:59:37', '14:59:41', 1),
(46, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:59:56', '15:12:12', 1),
(47, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '14:59:59', '15:02:20', 1),
(48, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:11:59', '15:12:19', 1),
(49, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:12:14', '15:37:10', 1),
(50, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:37:15', '15:37:21', 1),
(51, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:38:33', '15:38:55', 1),
(52, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:38:43', '15:38:48', 1),
(53, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:39:10', '15:42:09', 1),
(54, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:42:03', '15:42:05', 1),
(55, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:42:20', '15:42:35', 1),
(56, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:43:53', '15:44:06', 1),
(57, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:45:08', '15:45:33', 1),
(58, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:45:21', '15:48:00', 1),
(59, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:45:35', '15:47:08', 1),
(60, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:48:05', '15:49:48', 1),
(61, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:48:11', '15:50:07', 1),
(62, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:50:25', '15:56:06', 1),
(63, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:50:34', '15:54:49', 1),
(64, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:55:47', '16:05:04', 1),
(65, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:56:08', '15:56:35', 1),
(66, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:56:38', '15:58:45', 1),
(67, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '15:58:54', '16:01:24', 1),
(68, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '16:03:35', '16:09:30', 1),
(69, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '16:05:10', '16:07:19', 1),
(70, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '16:07:27', '16:07:39', 1),
(71, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '16:09:25', '16:15:10', 1),
(72, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '16:09:41', '16:11:10', 1),
(73, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '16:11:16', '16:15:05', 1),
(74, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '16:15:12', '21:18:30', 1),
(75, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '21:18:17', '21:18:34', 1),
(76, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '21:18:42', '21:35:11', 1),
(77, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '21:31:30', '21:35:21', 1),
(78, 'jimboy', 12, '13715982162', '249c2936ed4737e1', 'First floor', '2021-04-22', '21:35:17', '21:45:49', 1),
(79, 'kiel', 123, '247267999', '249c2936ed4737e1', 'First floor', '2021-04-22', '21:46:02', '00:00:00', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_logs`
--
ALTER TABLE `users_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users_logs`
--
ALTER TABLE `users_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
